- actiave the env - conda activate <env_name>

- install the libraires ---> pip install flask
to check all the packages installed in a partiuclar env - pip list

create an env ---> conda create -n deployement python==3.7

activate the enc --> conda activate deployment

the check all the env --> conda env list

to check the python version --> python --version


to save all the libraries in txt file --> pip freeze > requirement.txt

to put all the lib inside a virtual env ---> pip install -r requirment.txt